#Write a program to copy a text file using file handling mechanism.
source = open("source.txt", "r")

destination = open("copy.txt", "w")

content = source.read()

destination.write(content)

source.close()
destination.close()

print("File copied successfully!")
