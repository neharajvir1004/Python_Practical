#Module Example

from mymodule import *

print(add(10,5))
print(subtract(10,5))
print(greet("Student"))
print(square(6))
