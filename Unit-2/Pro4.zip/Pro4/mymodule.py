# mymodule.py

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def greet(name):
    return "Hello " + name

def square(n):
    return n * n
