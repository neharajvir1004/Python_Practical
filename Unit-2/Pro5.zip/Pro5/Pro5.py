# Open and read file

file = open("sample.txt", "r")

content = file.read()
print("File Content:\n")
print(content)

words = content.split()
print("\nNumber of words in file:", len(words))

file.close()
