#Write a program to read a file which contains only numbers. Display total of all numbers with maximum and minimum number.
file = open("numbers.txt", "r")

numbers = []

for line in file:
    numbers.append(int(line.strip()))

file.close()

total = sum(numbers)
maximum = max(numbers)
minimum = min(numbers)

print("Total =", total)
print("Maximum =", maximum)
print("Minimum =", minimum)
