#Write a program to read file which has marks entry of student and display details with total, percentage and grade (Consider a file which has comma separated data with RollNo, Student Name, Mark1, Mark2, Mark3 and Mark4)

file = open("marks.txt", "r")

for line in file:
    data = line.strip().split(",")
    
    rollno = data[0]
    name = data[1]
    m1 = int(data[2])
    m2 = int(data[3])
    m3 = int(data[4])
    m4 = int(data[5])
    
    total = m1 + m2 + m3 + m4
    percentage = total / 4
    
    if percentage >= 75:
        grade = "A"
    elif percentage >= 60:
        grade = "B"
    elif percentage >= 50:
        grade = "C"
    else:
        grade = "D"

    print("Roll No:", rollno)
    print("Name:", name)
    print("Total:", total)
    print("Percentage:", percentage)
    print("Grade:", grade)
    print("-----------------------")

file.close()
