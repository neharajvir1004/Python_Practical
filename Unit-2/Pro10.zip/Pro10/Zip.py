import zipfile

# Create a zip file
with zipfile.ZipFile("myfiles.zip", "w") as z:
    z.write("sample.txt")   

print("File zipped successfully!")
