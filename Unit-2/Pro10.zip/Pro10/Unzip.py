import zipfile

# Open zip file
with zipfile.ZipFile("myfiles.zip", "r") as z:
    z.extractall("extracted_files")  

print("File unzipped successfully!")
