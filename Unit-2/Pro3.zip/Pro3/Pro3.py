import logging


logging.basicConfig(
    filename="error_log.txt",   
    level=logging.ERROR,        
    format="%(asctime)s - %(levelname)s - %(message)s"
)

try:
   
    a = 10
    b = 0
    result = a / b   

except ZeroDivisionError as e:
    print("Arithmetic Exception Occurred!")

    logging.error("Exception occurred", exc_info=True)
    
    print("Exception logged in error_log.txt")
